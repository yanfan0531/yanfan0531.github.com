Readme for relations in paper “Learning Fine-grained Relations from Chinese User Generated Categories”

###################### data format ######################

Each relational fact is written in one line, with the format:entity1 \t relation predicate \t entity2

############################## dataset description ##############################

This dataset contains relation triples extracted from Chinese Wikipedia categories.