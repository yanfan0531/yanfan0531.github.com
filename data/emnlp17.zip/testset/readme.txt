Readme for dataset in paper “Learning Fine-grained Relations from Chinese User Generated Categories”

###################### data format ######################entity \t category \t labellabel = 1 category is a hypernym of entity.label = 0 otherwise.

############################## dataset description ##############################

This dataset contains 1788 entity-category pairs randomly sampled from Chinese Wikipedia.
The labels are added by multiple human annotators. It can be used for predicting is-a relations from Chinese term pairs.


