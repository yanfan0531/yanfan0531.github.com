训练数据一共包括四个关系种类：
1. [影视作品]-执导-[人物]，directing.txt, 共633条
2. [人物]-配偶-[人物], couple.txt, 共590条
3. [专辑]-演唱者-[人物], singing.txt, 共648条
4. [影视作品]-演员为-[人物], starring.txt, 共1609条
未标注数据一共有3161条。
注意，由于采用远程监督方法自动标注文本数据，有可能会由于NER的识别问题出现少量伪正例。

如果在文章中采用我们的数据，请引用文章：
@inproceedings{coling2018,
  author    = {Yan Fan and
		Chengyu Wang and
               Xiaofeng He},
  title     = {Exploratory Neural Relation Classification for Domain Knowledge Acquisition},
  booktitle = {Proceedings of the 27th International Conference on Computational Linguistics},
  pages     = {2265--2276},
  year      = {2018}
}

后续还会在个人主页上公开更大规模的中文娱乐领域知识图谱，详情请见https://yanfan0531.github.io/。