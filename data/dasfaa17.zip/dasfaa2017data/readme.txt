该数据集是从维基百科的信息框和类别标签中抽取出的娱乐领域知识图谱。
一共包含三个文件：
1. entity.csv; 每一行为: id和实体名称; 共包含10w个实体
2. relation.csv; 每一行为: 源实体的id, 关系种类名称, 目标实体的id; 共包含48w个实例
3. attribute.csv; 每一行为: 实体的id, 属性种类名称，属性值; 共包含25w个实例

注意，由于部分实例由算法自动抽取，且考虑到规则抽取器无法覆盖所有的情况，因此会出现bad cases，总体准确率在93%左右。

如果需要使用此数据集，请引用我们的文章，谢谢：
@inproceedings{dasfaa2017,
  author    = {Yan Fan and
               Chengyu Wang and
               Guomin Zhou and
               Xiaofeng He},
  title     = {DKGBuilder: An Architecture for Building a Domain Knowledge Graph
               from Scratch},
  booktitle = {Proceedings of the 22nd International Conference on Database Systems for Advanced Applications, Part {II}},
  pages     = {663--667},
  year      = {2017}
}

